﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace RealEstateAgency
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        Database.Entities entities = new Database.Entities();
        public MainWindow()
        {
            InitializeComponent();

            FiltrObjectInput.ItemsSource = entities.RealEstate.Select(x => x.Name).ToList();

            ClientsOutput.ItemsSource = entities.Clients.ToList();
            AgentsOutput.ItemsSource = entities.Agents.ToList();
            ObjectOutput.ItemsSource = entities.Object.ToList();
            OfferOutput.ItemsSource = entities.Offer.ToList();
            DemandOutput.ItemsSource = entities.ObjectDemands.ToList();
        }

        private void ClientsButtom_Click(object sender, RoutedEventArgs e)
        {
            ClientsWindow.Visibility = Visibility.Visible;
            AgentsWindow.Visibility = Visibility.Hidden;
            ObjectWindow.Visibility = Visibility.Hidden;
            OfferWindow.Visibility = Visibility.Hidden;
            DemandWindow.Visibility = Visibility.Hidden;
        }        

        private void AgentsButton_Click(object sender, RoutedEventArgs e)
        {
            ClientsWindow.Visibility = Visibility.Hidden;
            AgentsWindow.Visibility = Visibility.Visible;
            ObjectWindow.Visibility = Visibility.Hidden;
            OfferWindow.Visibility = Visibility.Hidden;
            DemandWindow.Visibility = Visibility.Hidden;
        }
        private void ObjectButton_Click(object sender, RoutedEventArgs e)
        {
            ClientsWindow.Visibility = Visibility.Hidden;
            AgentsWindow.Visibility = Visibility.Hidden;
            ObjectWindow.Visibility = Visibility.Visible;
            OfferWindow.Visibility = Visibility.Hidden;
            DemandWindow.Visibility = Visibility.Hidden;
        }
        private void OfferButton_Click(object sender, RoutedEventArgs e)
        {
            ClientsWindow.Visibility = Visibility.Hidden;
            AgentsWindow.Visibility = Visibility.Hidden;
            ObjectWindow.Visibility = Visibility.Hidden;
            OfferWindow.Visibility = Visibility.Visible;
            DemandWindow.Visibility = Visibility.Hidden;
        }
        private void DemandsButton_Click(object sender, RoutedEventArgs e)
        {
            ClientsWindow.Visibility = Visibility.Hidden;
            AgentsWindow.Visibility = Visibility.Hidden;
            ObjectWindow.Visibility = Visibility.Hidden;
            OfferWindow.Visibility = Visibility.Hidden;
            DemandWindow.Visibility = Visibility.Visible;
        }       

        private void AddClientButton_Click(object sender, RoutedEventArgs e)
        {
            WindowGroup.AddClientWindow addClientWindow = new WindowGroup.
                AddClientWindow(entities, new Database.Clients());
            if (addClientWindow.ShowDialog() == true)
            {
                ClientsOutput.ItemsSource = entities.Clients.ToList();
            }
        }
        private void AddAgentButton_Click(object sender, RoutedEventArgs e)
        {
            WindowGroup.AddAgentWindow addAgentWindow = new WindowGroup.
                AddAgentWindow(entities, new Database.Agents());
            if (addAgentWindow.ShowDialog() == true)
            {
                AgentsOutput.ItemsSource = entities.Agents.ToList();
            }
        }
        private void AddObjectButton_Click(object sender, RoutedEventArgs e)
        {
            WindowGroup.AddObjectWindow addObjectWindow = new WindowGroup.
                AddObjectWindow(entities, new Database.Object());
            if(addObjectWindow.ShowDialog() == true)
            {
                ObjectOutput.ItemsSource = entities.Object.ToList();
            }
        }
        private void AddOfferButton_Click(object sender, RoutedEventArgs e)
        {
            WindowGroup.AddOfferWindow addOfferWindow = new WindowGroup.
                AddOfferWindow(entities, new Database.Offer());
            if(addOfferWindow.ShowDialog() == true)
            {
                OfferOutput.ItemsSource= entities.Offer.ToList();
            }
        }
        private void AddDemandButton_Click(object sender, RoutedEventArgs e)
        {
            WindowGroup.AddDemandWindow addDemandWindow = new WindowGroup.
                AddDemandWindow(entities, new Database.ObjectDemands());
            if(addDemandWindow.ShowDialog() == true)
            {
                DemandOutput.ItemsSource = entities.ObjectDemands.ToList();
            }
        }

        private void ReplaseClientButton_Click(object sender, RoutedEventArgs e)
        {
            var rowSelected = ClientsOutput.SelectedItem as Database.Clients;

            if (rowSelected == null)
            {
                MessageBox.Show("Не выбрана строка для редактирования!");
            }
            else
            {
                WindowGroup.AddClientWindow addClientWindow = new WindowGroup.
                    AddClientWindow(entities, rowSelected);
                if (addClientWindow.ShowDialog() == true)
                {
                    FindClientinput_TextChanged(null, null);
                }
            }
        }
        private void ReplaseAgentButton_Click(object sender, RoutedEventArgs e)
        {
            var rowSelected = AgentsOutput.SelectedItem as Database.Agents;

            if (rowSelected == null)
            {
                MessageBox.Show("Не выбрана строка для редактирования!");
            }
            else
            {
                WindowGroup.AddAgentWindow addAgentWindow = new WindowGroup.
                    AddAgentWindow(entities, rowSelected);
                if (addAgentWindow.ShowDialog() == true)
                {
                    FindAgentInput_TextChanged(null, null);
                }
            }
        }

        private void ReplaseObjectButton_Click(object sender, RoutedEventArgs e)
        {
            var rowSelected = ObjectOutput.SelectedItem as Database.Object;

            if (rowSelected == null)
            {
                MessageBox.Show("Не выбрана строка для редактирования!");
            }
            else
            {
                WindowGroup.AddObjectWindow addObjectWindow = new WindowGroup.
                AddObjectWindow(entities, rowSelected);
                if (addObjectWindow.ShowDialog() == true)
                {
                    ObjectFilter(string.Empty, string.Empty);
                }
            }
        }
        private void ReplaseOfferButton_Click(object sender, RoutedEventArgs e)
        {
            var rowSelected = OfferOutput.SelectedItem as Database.Offer;

            if (rowSelected == null)
            {
                MessageBox.Show("Не выбрана строка для редактирования!");
            }
            else
            {
                WindowGroup.AddOfferWindow addOfferWindow = new WindowGroup.
                AddOfferWindow(entities, rowSelected);
                if (addOfferWindow.ShowDialog() == true)
                {
                    OfferOutput.ItemsSource = entities.Offer.ToList();
                }
            }
        }
        private void ReplaseDemandButton_Click(object sender, RoutedEventArgs e)
        {
            var rowSelected = DemandOutput.SelectedItem as Database.ObjectDemands;

            if (rowSelected == null)
            {
                MessageBox.Show("Не выбрана строка для редактирования!");
            }
            else
            {
                WindowGroup.AddDemandWindow addDemandWindow = new WindowGroup.
                AddDemandWindow(entities, rowSelected);
                if (addDemandWindow.ShowDialog() == true)
                {
                    DemandOutput.ItemsSource = entities.ObjectDemands.ToList();
                }
            }
        }

        private void RemoveClientButton_Click(object sender, RoutedEventArgs e)
        {
            var rowSelected = ClientsOutput.SelectedItem as Database.Clients;

            if(rowSelected == null)
            {
                MessageBox.Show("Не выбрана строка для удаления!");
            }
            else
            {
                MessageBoxResult result = MessageBox.Show("Вы точно хотите " +
                    "удалить клиента?", "Уведомление!", MessageBoxButton.YesNo);

                if(result == MessageBoxResult.Yes)
                {
                    if(rowSelected.ObjectDemands.Count() == 0 && 
                        rowSelected.Deal.Count() == 0)
                    {
                        entities.Clients.Remove(rowSelected);
                        entities.SaveChanges();
                        FindClientinput_TextChanged(null, null);
                    }
                    else
                    {
                        MessageBox.Show("Данный клиент не может быть удален," +
                            "\nтак как имеет дополнительные записи!", "Ошибка!",
                            MessageBoxButton.OK, MessageBoxImage.Error);
                    }
                }
            }
        }       

        private void RemoveAgentButton_Click(object sender, RoutedEventArgs e)
        {
            var rowSelected = AgentsOutput.SelectedItem as Database.Agents;

            if (rowSelected == null)
            {
                MessageBox.Show("Не выбрана строка для удаления!");
            }
            else
            {
                MessageBoxResult result = MessageBox.Show("Вы точно хотите " +
                    "удалить риэлтора?", "Уведомление!", MessageBoxButton.YesNo);

                if (result == MessageBoxResult.Yes)
                {
                    if (rowSelected.ObjectDemands.Count() == 0 &&
                        rowSelected.Deal.Count() == 0)
                    {
                        entities.Agents.Remove(rowSelected);
                        entities.SaveChanges();
                        FindAgentInput_TextChanged(null, null);
                    }
                    else
                    {
                        MessageBox.Show("Данный риэлтор не может быть удален," +
                            "\nтак как имеет дополнительные записи!", "Ошибка!",
                            MessageBoxButton.OK, MessageBoxImage.Error);
                    }
                }
            }
        }
        private void RemoveObjectButton_Click(object sender, RoutedEventArgs e)
        {
            var rowSelected = ObjectOutput.SelectedItem as Database.Object;

            if (rowSelected == null)
            {
                MessageBox.Show("Не выбрана строка для удаления!");
            }
            else
            {
                MessageBoxResult result = MessageBox.Show("Вы точно хотите " +
                    "удалить недвижимость?", "Уведомление!", MessageBoxButton.YesNo);

                if (result == MessageBoxResult.Yes)
                {
                    entities.Object.Remove(rowSelected);
                    entities.SaveChanges();
                    ObjectFilter(string.Empty, string.Empty);
                }
            }
        }
        private void RemoveOfferButton_Click(object sender, RoutedEventArgs e)
        {
            var rowSelected = OfferOutput.SelectedItem as Database.Offer;

            if (rowSelected == null)
            {
                MessageBox.Show("Не выбрана строка для удаления!");
            }
            else
            {
                MessageBoxResult result = MessageBox.Show("Вы точно хотите " +
                    "удалить предложение?", "Уведомление!", MessageBoxButton.YesNo);

                if (result == MessageBoxResult.Yes)
                {
                    if (rowSelected.Deal.Count() == 0)
                    {
                        entities.Offer.Remove(rowSelected);
                        entities.SaveChanges();
                        OfferOutput.ItemsSource = entities.Offer.ToList();
                    }
                    else
                    {
                        MessageBox.Show("Данное предложение не может быть удалено," +
                            "\nтак как имеет дополнительные записи!", "Ошибка!",
                            MessageBoxButton.OK, MessageBoxImage.Error);
                    }
                }
            }
        }
        private void RemoveDemandButton_Click(object sender, RoutedEventArgs e)
        {
            var rowSelected = DemandOutput.SelectedItem as Database.ObjectDemands;

            if (rowSelected == null)
            {
                MessageBox.Show("Не выбрана строка для удаления!");
            }
            else
            {
                MessageBoxResult result = MessageBox.Show("Вы точно хотите " +
                    "удалить потребность?", "Уведомление!", MessageBoxButton.YesNo);

                if (result == MessageBoxResult.Yes)
                {
                    if (rowSelected.Deal.Count() == 0)
                    {
                        entities.ObjectDemands.Remove(rowSelected);
                        entities.SaveChanges();
                        DemandOutput.ItemsSource = entities.ObjectDemands.ToList();
                    }
                    else
                    {
                        MessageBox.Show("Данная потребность не может быть удалена," +
                            "\nтак как имеет дополнительные записи!", "Ошибка!",
                            MessageBoxButton.OK, MessageBoxImage.Error);
                    }
                }
            }
        }

        private void FindClientinput_TextChanged(object sender, TextChangedEventArgs e)
        {
            var text = FindClientinput.Text;

            if (text == string.Empty)
            {
                ClientsOutput.ItemsSource = entities.Clients.ToList();
            }
            else
            {
                ClientsOutput.ItemsSource = entities.Clients
                    .Where(x => x.FirstName.Contains(text) ||
                    x.MiddleName.Contains(text) ||
                    x.LastName.Contains(text))
                    .ToList();
            }
        }

        private void FindAgentInput_TextChanged(object sender, TextChangedEventArgs e)
        {
            var text = FindAgentInput.Text;

            if (text == string.Empty)
            {
                AgentsOutput.ItemsSource = entities.Agents.ToList();
            }
            else
            {
                AgentsOutput.ItemsSource = entities.Agents
                    .Where(x => x.FirstName.Contains(text) ||
                    x.MiddleName.Contains(text) ||
                    x.LastName.Contains(text))
                    .ToList();
            }
        }      

        private void FindObjectInput_TextChanged(object sender, TextChangedEventArgs e)
        {
            ObjectFilter(FindObjectInput.Text, FiltrObjectInput.Text);
        }

        private void FiltrObjectInput_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            ObjectFilter(FindObjectInput.Text, e.AddedItems[0] as string);
        }

        private void ObjectFilter(string find, string type)
        {
            var estates = entities.Object.ToList();

            if (find != string.Empty)
            {
                estates = estates
                    .Where(x => x.Address_City.Contains(find) ||
                    x.Address_Street.Contains(find)).ToList();
            }

            if (type != string.Empty)
            {
                estates = estates.Where(x => x.RealEstate.Name == type).ToList();
            }

            ObjectOutput.ItemsSource = estates;
        }
    }
}
