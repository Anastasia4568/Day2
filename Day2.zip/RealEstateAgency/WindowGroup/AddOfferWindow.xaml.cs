﻿using System;
using RealEstateAgency.Database;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Text.RegularExpressions;

namespace RealEstateAgency.WindowGroup
{
    /// <summary>
    /// Логика взаимодействия для AddOfferWindow.xaml
    /// </summary>
    public partial class AddOfferWindow : Window
    {
        Entities entities;
        Offer offer;
        public AddOfferWindow(Entities entities, Offer offer)
        {
            InitializeComponent();
            this.entities = entities;
            this.offer = offer;

            ClientInput.ItemsSource = entities.Clients.ToList();
            AgentInput.ItemsSource = entities.Agents.ToList();
            EstateAgencyInput.ItemsSource = entities.Object.ToList();

            if (offer.Id != 0)
            {
                ClientInput.Text = offer.Clients.FullName;
                AgentInput.Text = offer.Agents.FullName;
                EstateAgencyInput.Text = offer.Object.Address;
                PriceInput.Text = offer.Price.ToString();
            }
        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            if (ClientInput.Text == string.Empty ||
                AgentInput.Text == string.Empty ||
                EstateAgencyInput.Text == string.Empty ||
                PriceInput.Text == string.Empty)
            {
                MessageBox.Show("Не все данные введены!");
            }
            else
            {
                var id = 1;
                if (entities.Offer.Count() != 0)
                {
                    id += entities.Offer.Max(x => x.Id);
                }

                if (offer.Id == 0)
                {
                    offer.Id = id;
                    offer.ClientId = (int)ClientInput.SelectedValue;
                    offer.AgentId = (int)AgentInput.SelectedValue;
                    offer.ObjectId = (int)EstateAgencyInput.SelectedValue;
                    offer.Price = Convert.ToDecimal(PriceInput.Text);

                    entities.Offer.Add(offer);
                    entities.SaveChanges();

                    DialogResult = true;
                }
                else
                {
                    offer.ClientId = (int)ClientInput.SelectedValue;
                    offer.AgentId = (int)AgentInput.SelectedValue;
                    offer.ObjectId = (int)EstateAgencyInput.SelectedValue;
                    offer.Price = Convert.ToDecimal(PriceInput.Text);
                    entities.SaveChanges();

                    DialogResult = true;
                }
            }
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            this.DialogResult = false;
        }

        private void PriceInput_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            if (!Char.IsDigit(e.Text[0]))
            {
                e.Handled = true;
            }
        }
    }
}
