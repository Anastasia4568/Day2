﻿using System;
using RealEstateAgency.Database;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace RealEstateAgency.WindowGroup
{
    /// <summary>
    /// Логика взаимодействия для AddDemandWindow.xaml
    /// </summary>
    public partial class AddDemandWindow : Window
    {
        Entities entities;
        ObjectDemands demands;
        public AddDemandWindow(Entities entities, ObjectDemands demands)
        {
            InitializeComponent();
            this.entities = entities;
            this.demands = demands;

            ClientInput.ItemsSource = entities.Clients.ToList();
            AgentInput.ItemsSource = entities.Agents.ToList();
            RealEstateInput.ItemsSource = entities.RealEstate.ToList();

            if (demands.Id != 0)
            {
                CityInput.Text = demands.Address_City;
                StreetInput.Text = demands.Address_Street;
                HouseInput.Text = demands.Address_House.ToString();
                NumberInput.Text = demands.Address_Number.ToString();
                RealEstateInput.Text = demands.RealEstate.Name;
                MinPriceInput.Text = demands.MinPrice.ToString();
                MaxPriceInput.Text = demands.MaxPrice.ToString();
                AgentInput.Text = demands.Agents.FullName;
                ClientInput.Text = demands.Clients.FullName;
                MinAreaInput.Text = demands.MinArea.ToString();
                MaxAreaInput.Text = demands.MaxArea.ToString();
                MinRoomsInput.Text = demands.MinRooms.ToString();
                MaxRoomsInput.Text = demands.MaxRooms.ToString();
                MinFloorInput.Text = demands.MinFloor.ToString();
                MaxFloorInput.Text = demands.MaxFloor.ToString();
            }
        }
        private double? TryConvert(string number)
        {
            if (number == string.Empty)
            {
                return null;
            }
            else
            {
                return Convert.ToDouble(number);
            }
        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            if (ClientInput.Text == string.Empty ||
                AgentInput.Text == string.Empty ||
                RealEstateInput.Text == string.Empty)
            {
                MessageBox.Show("Не все данные введены!");
            }
            else
            {
                var id = entities.ObjectDemands.Max(x => x.Id) + 1;                

                if (demands.Id == 0)
                {
                    demands.Id = id;
                    demands.Address_City = CityInput.Text;
                    demands.Address_Street = StreetInput.Text;
                    demands.Address_House = (int?)TryConvert(HouseInput.Text);
                    demands.Address_Number = (int?)TryConvert(NumberInput.Text);
                    demands.RealEstateId = (int)RealEstateInput.SelectedValue;
                    demands.MinPrice = TryConvert(MinPriceInput.Text);
                    demands.MaxPrice = TryConvert(MaxPriceInput.Text);
                    demands.AgentId = (int)AgentInput.SelectedValue;
                    demands.ClientId = (int)ClientInput.SelectedValue;
                    demands.MinArea = TryConvert(MinAreaInput.Text);
                    demands.MaxArea = TryConvert(MaxAreaInput.Text);
                    demands.MinRooms = (int?)TryConvert(MinRoomsInput.Text);
                    demands.MaxRooms = (int?)TryConvert(MaxRoomsInput.Text);
                    demands.MinFloor = (int?)TryConvert(MinFloorInput.Text);
                    demands.MaxFloor = (int?)TryConvert(MaxFloorInput.Text);

                    entities.ObjectDemands.Add(demands);
                    entities.SaveChanges();

                    DialogResult = true;
                }
                else
                {
                    demands.Address_City = CityInput.Text;
                    demands.Address_Street = StreetInput.Text;
                    demands.Address_House = (int?)TryConvert(HouseInput.Text);
                    demands.Address_Number = (int?)TryConvert(NumberInput.Text);
                    demands.RealEstateId = (int)RealEstateInput.SelectedValue;
                    demands.MinPrice = TryConvert(MinPriceInput.Text);
                    demands.MaxPrice = TryConvert(MaxPriceInput.Text);
                    demands.AgentId = (int)AgentInput.SelectedValue;
                    demands.ClientId = (int)ClientInput.SelectedValue;
                    demands.MinArea = TryConvert(MinAreaInput.Text);
                    demands.MaxArea = TryConvert(MaxAreaInput.Text);
                    demands.MinRooms = (int?)TryConvert(MinRoomsInput.Text);
                    demands.MaxRooms = (int?)TryConvert(MaxRoomsInput.Text);
                    demands.MinFloor = (int?)TryConvert(MinFloorInput.Text);
                    demands.MaxFloor = (int?)TryConvert(MaxFloorInput.Text);
                    entities.SaveChanges();

                    DialogResult = true;
                }
            }
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            this.DialogResult = false;
        }
        private void CityInput_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            if(!Char.IsLetter(e.Text, 0))
            {
                e.Handled = true;
            }
        }

        private void HouseInput_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            if (!Char.IsDigit(e.Text, 0))
            {
                e.Handled = true;
            }
        }
    }
}
