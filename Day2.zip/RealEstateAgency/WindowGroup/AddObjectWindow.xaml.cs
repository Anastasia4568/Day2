﻿using RealEstateAgency.Database;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using static System.Net.Mime.MediaTypeNames;

namespace RealEstateAgency.WindowGroup
{
    /// <summary>
    /// Логика взаимодействия для AddObjectWindow.xaml
    /// </summary>
    public partial class AddObjectWindow : Window
    {
        Entities entities;
        Database.Object estate;
        public AddObjectWindow(Entities entities, Database.Object estate)
        {
            InitializeComponent();
            this.entities = entities;
            this.estate = estate;

            RealEstateInput.ItemsSource = entities.RealEstate.ToList();

            if(estate.Id != 0)
            {
                CityInput.Text = estate.Address_City;
                StreetInput.Text = estate.Address_Street;
                HouseInput.Text = estate.Address_House.ToString();
                NumberInput.Text = estate.Address_Number.ToString();
                LatitudeInput.Text = estate.Coordinate_latitude.ToString();
                LongitudeInput.Text = estate.Coordinate_longitude.ToString();
                TotalAreaInput.Text = estate.TotalArea.ToString();
                RoomsInput.Text = estate.Rooms.ToString();
                FloorInput.Text = estate.Floor.ToString();
                RealEstateInput.Text = estate.RealEstate.Name.ToString();
            }
        }
        private double? TryConvert(string number)
        {
            if (number == string.Empty)
            {
                return null;
            }
            else
            {
                return Convert.ToDouble(number);
            }
        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            if (TotalAreaInput.Text == string.Empty ||
                RoomsInput.Text == string.Empty ||
                FloorInput.Text == string.Empty ||
                RealEstateInput.Text == string.Empty)
            {
                MessageBox.Show("Не все данные введены!");
            }
            else
            {                
                var id = entities.Object.Max(x => x.Id) + 1;
                if (estate.Id == 0)
                {
                    estate.Id = id;
                    estate.Address_City = CityInput.Text;
                    estate.Address_Street = StreetInput.Text;
                    estate.Address_House = (int?)TryConvert(HouseInput.Text);
                    estate.Address_Number = (int?)TryConvert(NumberInput.Text);
                    estate.Coordinate_latitude = (int?)TryConvert(LatitudeInput.Text);
                    estate.Coordinate_longitude = (int?)TryConvert(LongitudeInput.Text);
                    estate.TotalArea = TryConvert(TotalAreaInput.Text);
                    estate.Rooms = (int?)TryConvert(RoomsInput.Text);
                    estate.Floor = (int?)TryConvert(FloorInput.Text);
                    estate.RealEstateId = (int)RealEstateInput.SelectedValue;

                    entities.Object.Add(estate);
                    entities.SaveChanges();

                    DialogResult = true;
                }
                else
                {
                    estate.Address_City = CityInput.Text;
                    estate.Address_Street = StreetInput.Text;
                    estate.Address_House = (int?)TryConvert(HouseInput.Text);
                    estate.Address_Number = (int?)TryConvert(NumberInput.Text);
                    estate.Coordinate_latitude = (int?)TryConvert(LatitudeInput.Text);
                    estate.Coordinate_longitude = (int?)TryConvert(LongitudeInput.Text);
                    estate.TotalArea = TryConvert(TotalAreaInput.Text);
                    estate.Rooms = (int?)TryConvert(RoomsInput.Text);
                    estate.Floor = (int?)TryConvert(FloorInput.Text);
                    estate.RealEstateId = (int?)RealEstateInput.SelectedValue;

                    entities.SaveChanges();

                    DialogResult = true;
                }
            }
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            this.DialogResult = false;
        }

        private void HouseInput_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            if(!Char.IsDigit(e.Text, 0))
            {
                e.Handled = true;
            }
        }

        private void CityInput_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            if (!Char.IsLetter(e.Text, 0))
            {
                e.Handled = true;
            }
        }
    }
}
